﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class MageClass : PlayerPawn
{
    public float MovementSpeed = 10;
    public float RotationSpeed = 180;
    public GameObject Slash;
    public GameObject attackpoint;

    Rigidbody rb;
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();

    }
    private void Update()
    {
        if (MageHealth <= 0)
        {
            Destroy(gameObject);
        }
    }
    public override void Horizontal(float value)
    {
        transform.Rotate(Vector3.up * Time.deltaTime * value * RotationSpeed);
    }

    public override void Vertical(float value)
    {
        transform.Translate(Vector3.forward * Time.deltaTime * value * MovementSpeed);
    }
    public override void Fire1(bool value)
    {
        GameObject Spam = Instantiate(Slash, attackpoint.transform.position, attackpoint.transform.rotation);
    }

    public override void Fire2(bool value)
    {
        
    }
    public override void Fire3(bool value)
    {

    }
    public override void Fire4(bool value)
    {

    }
}
