﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class PlayerPawn : Pawn
{

    public static int NextPlayerArenaCount = 0;
    public static int NextBossArenaCount = 0;
    public Text NextPlayerArenaCountText;
    public Text NextBossArenaCountText;
    string ArenaStarting = "StartingArena";
    string ArenaTwoScenePlayer1 = "PlayerWinArenaOne(Leech)";
    string ArenaTwoSceneBoss1 = "BossWinArenaOne(Leech)";
    string ArenaThreeScenePlayer2 = "PlayerWinArenaTwo(Pit)";
    string ArenaThreeSceneBoss2 = "BossWinArenaTwo(Pit)";
    string Menu = "MainMenu";

    protected float DragonHealth = 2559.00f;
    protected float KnightHealth = 420.0f;
    protected float MageHealth = 365.0f;
    protected float PriestHealth = 365.0f;
    protected float RangerHealth = 385.0f;


    public void Update()
    {
        if (this.gameObject.tag == "StartingArena")
        {
            if (NextPlayerArenaCount == 1)
            {
                SceneManager.LoadScene(ArenaTwoScenePlayer1);
            }
        }
        if (this.gameObject.tag == "StartingArena")
        {
            if (NextBossArenaCount == 3)
            {
                SceneManager.LoadScene(ArenaTwoSceneBoss1);
            }
        }
        if (this.gameObject.tag == "PlayerWinArenaOne(Leech)")
        {
            if (NextPlayerArenaCount == 1)
            {
                SceneManager.LoadScene(ArenaThreeScenePlayer2);
            }
        }
        if (this.gameObject.tag == "PlayerWinArenaOne(Leech)")
        {
            if (NextBossArenaCount == 3)
            {
                SceneManager.LoadScene(ArenaStarting);
            }
        }
        if (this.gameObject.tag == "PlayerWinArenaTwo(Pit)")
        {
            if (NextPlayerArenaCount == 1)
            {
                SceneManager.LoadScene(Menu);
            }
        }
        if (this.gameObject.tag == "PlayerWinArenaTwo(Pit)")
        {
            if (NextBossArenaCount == 3)
            {
                SceneManager.LoadScene(ArenaTwoScenePlayer1);
            }
        }
        if (this.gameObject.tag == "BossWinArenaOne(Leech)")
        {
            if (NextBossArenaCount == 3)
            {
                SceneManager.LoadScene(ArenaThreeSceneBoss2);
            }
        }
        if (this.gameObject.tag == "BossWinArenaTwo(Pit)")
        {
            if (NextPlayerArenaCount == 1)
            {
                SceneManager.LoadScene(ArenaTwoSceneBoss1);
            }
        }
        if (this.gameObject.tag == "BossWinArenaTwo(Pit)")
        {
            if (NextBossArenaCount == 3)
            {
                SceneManager.LoadScene(Menu);
            }
        }
        if (this.gameObject.tag == "BossWinArenaOne(Leech)")
        {
            if (NextPlayerArenaCount == 1)
            {
                SceneManager.LoadScene(ArenaStarting);
            }
        }
        NextBossArenaCountText.text = "Player Deaths: " + NextBossArenaCount;
        NextPlayerArenaCountText.text = "Boss Death: " + NextPlayerArenaCount;
    }
    protected override bool ProcessDamage(Class Source, float Value, DamageEventInfo EventInfo, Controller Instigator)
    {
        KnightHealth -= Value;
        if (KnightHealth <= 0)
        {
            Destroy(gameObject);
            controller.OnDeath();
            NextBossArenaCount += 1;
            

        }
        MageHealth -= Value;
        if (MageHealth <= 0)
        {
            Destroy(gameObject);
            controller.OnDeath();
            NextBossArenaCount += 1;
        }
        PriestHealth -= Value;
        if (PriestHealth <= 0)
        {
            Destroy(gameObject);
            controller.OnDeath();
            NextBossArenaCount += 1;
        }
        RangerHealth -= Value;
        if (RangerHealth <= 0)
        {
            Destroy(gameObject);
            controller.OnDeath();
            NextBossArenaCount += 1;
        }
        DragonHealth -= Value;
        if (RangerHealth <= 0)
        {
            Destroy(gameObject);
            controller.OnDeath();
            NextPlayerArenaCount += 1;
        }
        return true;
    }
    public void Start()
    {
        {
            IgnoresDamage = false;
        }
    }
    public virtual void Horizontal(float value)
    {

    }

    public virtual void Vertical(float value)
    {

    }

    public virtual void Fire1(bool value)
    {

    }

    public virtual void Fire2(bool value)
    {

    }

    public virtual void Fire3(bool value)
    {

    }

    public virtual void Fire4(bool value)
    {

    }

    public virtual void Fire5(bool value)
    {

    }

    public virtual void Fire6(bool value)
    {

    }
}
